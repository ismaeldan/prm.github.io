# PRM-GRAVACOES

Copyright (c) 2025 PRM GRAVAÇOES

Todos os direitos reservados.

Este software é propriedade exclusiva da PRM GRAVAÇOES. Seu uso é restrito a funcionários, contratados ou parceiros autorizados. É proibida a cópia, redistribuição ou modificação deste código sem autorização expressa da empresa.

Para mais informações, entre em contato com: comercial@prmgravacoes.com.br
